#' ---
#' title: "Exercise Solutions"
#' subtitle: "Use of Historical Data in Clinical Trials: An Evidence Synthesis Approach"
#' author: "Sebastian Weber, Novartis AG and Satrajit Roychoudhury, Pfizer Inc"
#' date: "DIA Bayesian Working Group KOL Lecture Series, November 22nd 2019"
#' ---
##+ include=FALSE
library(bayesplot)
library(dplyr)
#'
#' # Vignette: Getting started with RBesT (binary)
#'
#' ## Task 1: Work through the vignette
#'
#' Please run step-wise through the R code of the vignette available
#' via the help system.

#+ include=FALSE,cache=TRUE
Sys.setenv(NOT_CRAN="true")
is_CRAN <- FALSE
source(system.file("doc/introduction.R", package="RBesT"), echo=TRUE)

#'
#' ## Task 2: How much is the type I error inflated for the robust MAP prior?
#'
#' It is first important to acknowledge that when using a Bayesian
#' analysis the type I error is not controlled; even if using standard
#' non-informtive priors like the uniform Beta(1,1). Before going into
#' further detail, let's recap a few details of our analysis. The
#' frequentist decision framework relies on rejecting H0 which is
#' defined commonly as the no effect hypothesis ($\theta_1 =
#' \theta_2$). The H0 is rejected whenever the probability for
#' observing a result as extreme or more extreme as seen in the trial
#' (the p-value) is less than the pre-specified $\alpha$. Whenever
#' this happens we reject H0 and accept Ha which leads to concluding
#' superiority (if indeed the response for active exceeds control).
#'
#' The Bayesian equivalent is to declare superiority if the posterior,
#' which is the result of conditioning the data with the likelihood
#' onto the prior, tells us that the mean difference of $\theta_1 -
#' \theta_2$ is with a probability of at least $1-\alpha$ greater than
#' 0.
#'
decision
#'
#' There are two key points here
#'
#' 1. The posterior is the result of *conditioning the prior on the trial data* => no interpretation under replication as we condition on the data at hand
#' 2. The prior is indistinguishable from the trial data => the prior is part of the posterior
#'
#' These points emphasize some key aspects of the well known Bayes rule
#'
#' $$ p(\theta_1,\theta_2|y) = \frac{p(y|\theta_1,\theta_2) \, p(\theta_1,\theta_2)}{p(y)}.$$
#'
#' Operating characersitics evaluate the frequency at which decisions
#' are made under replication when assuming some known parameter
#' values for $\theta_1$ and $\theta_2$. A consequence of the above
#' two points is that a Bayesian trial analysis will have operating
#' characeristics which *depend* on the sample size, prior chosen and
#' the assumed known parameter values. For large sample sizes the
#' prior becomes irrelevant while the reverse is true for small sample
#' sizes. Moreover, it is of relevance if the prior is in conflict with
#' the trail data or not. Under these circumstances a robust prior
#' will limit the impact the prior has.
#'
#' Let's first consider the type I error ($\theta = \theta_1 =
#' \theta_2$) for uniform priors and testing 6 vs 24 subjects:

ggplot(data.frame(theta=c(0, 1)), aes(x=theta)) +
    geom_hline(yintercept=0.05, linetype=2) +
        coord_cartesian(ylim=c(0,0.1)) +
            stat_function(fun=function(theta) design_uniform(theta, theta))

#' We see that for large $\theta$ the type I error exceeds 5% slightly
#' which is a consequence of 1+2 above (the Beta(1,1) conveys a tiny
#' bit of information). When going to larger sample sizes then this
#' effect vanishes:

design_uniform_100 <- oc2S(uniform_prior, uniform_prior, 100, 100, decision)
ggplot(data.frame(theta=c(0,1.0)), aes(x=theta)) +
    geom_hline(yintercept=0.05, linetype=2) +
        coord_cartesian(ylim=c(0,0.1)) +
            stat_function(fun=function(theta) design_uniform_100(theta, theta))

#'
#' When using an informative prior then the impact of the prior on the
#' decision amplifies with increasing mismatch between prior and
#' data. As a net effect the type I error is *increased* towards
#' larger response rates and *decreased* toward smaller response rate
#' in the example considered. Let's explore this using the informative
#' prior as used in the Ankylosing Spondilits example:
#'

ggplot(data.frame(theta=c(0, 1)), aes(x=theta)) +
    geom_hline(yintercept=0.05, linetype=2) +
    stat_function(fun=function(theta) design_uniform(theta, theta), aes(linetype="uniform")) +
        stat_function(fun=function(theta) design_nonrobust(theta, theta), aes(linetype="non-robust"))

#'
#' The reason for this large inflation of the type I error on the
#' right is due to the way in which the prior alters the
#' posterior. That is when we evaluate, for example, the type I error
#' for $\theta = 0.7 = \theta_1 = \theta_2$ we assume that the control
#' response rate *is* 70%. However, the prior suggests a different
#' reality:
summary(map)
#' It is illustrative to not only look at the frequency at which
#' decisions are taken, but to explore how the trial will operate for
#' various data scenarios when assuming some true value for the response
#' rate in each group. In the plots below "1" refers to active and
#' "2" to control.
#'

#+ include=FALSE
plot_posteriors <- function(prior1, prior2, n1, n2, decision) {
    ## visualize possible outcomes assuming some true parameter values
    class(prior1) <- c("betaMix", "mix")
    class(prior2) <- c("betaMix", "mix")
    function(theta1, theta2) {
        r1 <- rbinom(1, n1, theta1)
        r2 <- rbinom(1, n2, theta2)
        post1 <- postmix(prior1, r=r1, n=n1)
        post2 <- postmix(prior2, r=r2, n=n2)
        xbr <- seq(0,1, by=0.2)
        samp <- c(r1/n1, r2/n2)
        samp_labs <- c(paste0(r1, "/", n1), paste0(r2, "/", n2))
        labs <- seq(0,1, by=0.2)
        reject <- if(decision(post1, post2) == 1) "reject H0" else "accept H0"
        pl_prior <- ggplot(data.frame(theta=c(0, 1)), aes(x=theta)) +
            stat_function(fun=function(theta) dmix(prior1, theta), linetype=1) +
                    stat_function(fun=function(theta) dmix(prior2, theta), linetype=2) +
                        ggtitle("Prior", "Sample 1 (solid), Sample 2 (dashed)") +
                            vline_at(v=r1/n1, linetype=1) + vline_at(v=r2/n2, linetype=2) +
                                annotate("text", x=samp, y=c(3,5), label=samp_labs) +
                                    scale_x_continuous(breaks=xbr, labels=labs) +
                                        coord_cartesian(ylim=c(0,6.5)) +
                                        ylab(NULL)
        pl_post <- ggplot(data.frame(theta=c(0, 1)), aes(x=theta)) +
                stat_function(fun=function(theta) dmix(post1, theta), linetype=1) +
                    stat_function(fun=function(theta) dmix(post2, theta), linetype=2) +
                        vline_at(v=r1/n1, linetype=1) + vline_at(v=r2/n2, linetype=2) +
                            annotate("text", x=samp, y=c(3,5), label=samp_labs) +
                                scale_x_continuous(breaks=xbr, labels=labs) +
                                    coord_cartesian(ylim=c(0,6.5)) +
                                            ggtitle(paste0("Potential posterior, theta1=", theta1, " & theta2=", theta2), paste0("Sample 1 (solid) ", r1, "/", n1, ", Sample 2 (dashed) ", r2, "/", n2)) +
                                        ylab(NULL)
        pl_difference <- ggplot(data.frame(delta=c(-1, 1)), aes(x=delta)) +
            stat_function(fun=function(delta) dmixdiff(post1, post2, delta), linetype=1) +
                vline_0(linetype=3) + ggtitle(paste("Potential posterior difference, P(delta > 0) =", round(pmixdiff(post1, post2, 0, lower.tail=FALSE), 3), "-", reject)) +
                    ylab(NULL)
        bayesplot_grid(pl_prior, pl_post, pl_difference, legends=FALSE)
    }
}

plot_trial_scenarios <- plot_posteriors(treat_prior, map, 24, 6, decision)
plot_robust_scenarios <- plot_posteriors(treat_prior, map_robust, 24, 6, decision)
plot_uniform_scenarios <- plot_posteriors(uniform_prior, uniform_prior, 24, 6, decision)

#'
#' ### Scenario with a conflict between MAP prior and data
#'
set.seed(433)
#+ fig.width=6,fig.height=7
plot_trial_scenarios(0.7, 0.7)

#' ### Scenario with a conflict between MAP prior and data, but using uniform priors
#+ fig.width=6,fig.height=7
set.seed(433)
plot_uniform_scenarios(0.7, 0.7)

#'
#' ### Scenario with a conflict between MAP prior and data, but using a robust MAP prior
#'
#+ fig.width=6,fig.height=7
set.seed(433)
plot_robust_scenarios(0.7, 0.7)


if(FALSE) {
    ## only run this in RStudio
    library(manipulate)
    manipulate(plot_trial_scenarios(theta, theta), theta=slider(0, 1, 0.6))
}

#'
#' Optional: Explore how a double-criterion, which requires in
#' addition to statistical significance also the observation of
#' minimal median difference, helps to reduce excessive type I
#' errors... and why?
#'
#' For example we may ask for a minimal observed treatment effect of
#' 20% difference:
decision_dual <- decision2S(c(0.95, 0.5), c(0, 0.2), lower.tail=FALSE)
decision_dual


#'
#' ## Task 3: Compare operating characteristics for a robust MAP prior with 80% and 50% weight on the MAP prior.
#'
#'

map80_robust <- robustify(map, weight=0.2)
map50_robust <- robustify(map, weight=0.5)

design_map80_robust <- oc2S(map80_robust, treat_prior, 6, 24, decision)
design_map50_robust <- oc2S(map50_robust, treat_prior, 6, 24, decision)

true_theta <- seq(0.1,0.9, by=0.1)

#'
#' Type I error
#'
typeI_sens <- data.frame(true_theta=true_theta, map80=design_map80_robust(true_theta, true_theta), map50=design_map50_robust(true_theta, true_theta))
kable(typeI_sens, digits=2)

ggplot(data.frame(theta=c(0, 1)), aes(x=theta)) +
    geom_hline(yintercept=0.05, linetype=2) +
    stat_function(fun=function(theta) design_map80_robust(theta, theta), aes(linetype="MAP 80% / Robust 20%")) +
        stat_function(fun=function(theta) design_map50_robust(theta, theta), aes(linetype="MAP 50% / Robust 50%")) +
            ggtitle("Type I Error")

#'
#' Power
#'
theta_ctl <- 0.25
power_sens <- data.frame(true_theta1=theta_ctl, true_theta2=theta_ctl+seq(0,0.7,by=0.1)) %>%
    mutate(map80=design_map80_robust(true_theta1, true_theta2),
           map50=design_map50_robust(true_theta1, true_theta2))
kable(power_sens, digits=2)

ggplot(data.frame(delta=c(0, 0.7)), aes(x=delta)) +
    geom_hline(yintercept=0.8, linetype=2) +
    stat_function(fun=function(delta) design_map80_robust(theta_ctl, theta_ctl + delta), aes(linetype="MAP 80% / Robust 20%")) +
        stat_function(fun=function(delta) design_map50_robust(theta_ctl, theta_ctl + delta), aes(linetype="MAP 50% / Robust 50%")) +
            ggtitle("Power")

## original HalfNormal(0,1) MCMC analysis:
summary(map_mcmc)

#'
#' ## Task 4: Evaluate further the difference the prior on $\tau$ makes
#'
#' Recall that we can perform a sensitivity analysis with the update
#' command
set.seed(36546)
map_mcmc_sens <- update(map_mcmc, tau.prior=1/2)

summary(map_mcmc)$theta.pred
summary(map_mcmc_sens)$theta.pred

#' As we can see, there are no large difference betweens the MAP
#' priors obtained under either prior => there will not be any marked
#' differences in operating characeristics.
#'
#' The difference between the two posteriors is the prior on the
#' between-trial heterogeniety $\tau$. As we have a reasonable number
#' of 8 historical trials the influence of the prior is limited.
#'
summary(map_mcmc)$tau
summary(map_mcmc_sens)$tau

#' ## Task 5: Consider only 3 studies

AS_3 <- AS[1:3,]

#'
#' then the prior has a more pronounced effect. We can again use the
#' `update` function which changes the call we did originally to now
#' use the new data-set.
#'
map_mcmc_3 <- update(map_mcmc, data=AS_3)

#' To ensure that we actually performed the analysis we intended, we
#' can look at the printed output for this analysis

map_mcmc_3

#'
#' which shows in the "Call" line the actual command executed.
#'
map_mcmc_sens_3 <- update(map_mcmc_sens, data=AS_3)

#'
#' Now the differences are more marked between the two MAP priors
#'
summary(map_mcmc_3)$theta.pred
summary(map_mcmc_sens_3)$theta.pred

#'
#' which is due to a larger influence of the prior on the posterior -
#' in particular on $\tau$:
#'
summary(map_mcmc_3)$tau
summary(map_mcmc_sens_3)$tau


##+ include=FALSE
pl1 <- plot(map_mcmc)$forest_model + coord_flip(ylim=c(0, 0.7)) + ylab(NULL) + ggtitle("AS complete", "HalfNormal(0,1) tau prior")
pl2 <- plot(map_mcmc_sens)$forest_model  + coord_flip(ylim=c(0, 0.7)) + ylab(NULL) +ggtitle("AS complete", "HalfNormal(0,1/2) tau prior")
pl1_3 <- plot(map_mcmc_3)$forest_model + coord_flip(ylim=c(0, 0.7)) +  ggtitle("AS 3", "HalfNormal(0,1) tau prior")
pl2_3 <- plot(map_mcmc_sens_3)$forest_model  + coord_flip(ylim=c(0, 0.7)) + ggtitle("AS 3", "HalfNormal(0,1/2) tau prior")

##+ fig.width=6,fig.height=7,echo=FALSE
bayesplot_grid(pl1, pl2, pl1_3, pl2_3)

#'
#' # Probability of Success
#'
#' ## Task 1: Work through the probability of success material.
#'
#' Please execute and go through the `pos_codata.R` file provided with
#' the course material.
#'

#+ include=FALSE,cache=TRUE
source(system.file("doc/PoS_codata.R", package="RBesT"), echo=TRUE)

#'
#' ## Task 2: What is the probability of success for a phase III trial to be successful before initiating these based on the PoC and phase II data only?
#'
#' The historical information available at the planning stage for each
#' phase III study comprises the PoC and the phase II study. These
#' have been analyzed already:
base_map_mc
#' And the parametric mixture representing the MCMC MAP prior is:
plot(base_map)$mix

#' Now we are interested in knowing the PoS for the phase III trial to
#' be successfull prior to having seen any data yet. Thus, we need to
#' call the `pos1S` function such that the prior information on the
#' treatment effect is assumed non-informative and we request that the
#' planned sample size is to be collected:
pos_phaseIII <- pos1S(unit_inf, Nev, success_crit, sigma=2)

#' The probability that one phase III trial is successfull when
#' assuming that historical information from the PoC and phase II
#' study is our current (uncertain) knowledge about the treatment
#' effect is then simply
pos_phaseIII(base_map)

#' This calculation takes into account the limited sample size of the
#' available data and in addition heterogeniety between the trials.
#'
#'
#' ## Task 3: How large is the probability of success for both phase III studies to be successfull based on the historical data only?
#'
#' Both future trials are independent of one another. Therefore, the
#' probability for both trials being successfull is simply the square
#' of one being successful.
pos_phaseIII(base_map) * pos_phaseIII(base_map)

